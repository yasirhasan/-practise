import React,{Component} from 'react';
import Content from './Content'
export default class Home extends Component{
    constructor(props){
        super(props);
    }
    render (){
        return(
            <div>
                <Content/>
            </div>
        )
    }
}