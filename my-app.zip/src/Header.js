import React, { Component } from 'react'
import { Navbar, Nav, NavDropdown, Form, FormControl, Button } from 'react-bootstrap'
import {BrowserRouter as Router, NavLink } from 'react-router-dom'
//import Content from './Content'
export default class Header extends Component{
    constructor(props){
        super(props);
    }
    render (){
        return(
          <section>
              <div className="container">
                  <header>
                      <Navbar bg="light" expand="lg">
                          <Navbar.Brand href="#home">{this.props.title}</Navbar.Brand>
                          <Navbar.Toggle aria-controls="basic-navbar-nav" />

                      </Navbar>
                  </header>
              </div>
          </section>
        )
    }
}